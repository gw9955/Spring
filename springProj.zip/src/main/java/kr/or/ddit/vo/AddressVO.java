package kr.or.ddit.vo;

import lombok.Data;

//자바빈 클래스
@Data
public class AddressVO {
	private String postCode;
	private String location;
}
